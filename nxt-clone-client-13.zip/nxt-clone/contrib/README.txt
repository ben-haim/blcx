This directory contains scripts and tools contributed by the community.
They are not actively maintained by the Nxt core developers.

