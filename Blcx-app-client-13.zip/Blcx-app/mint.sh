#!/bin/sh
java -cp classes:lib/*:conf nxt.mint.MintWorker
